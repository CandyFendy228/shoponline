import React, { useState, useEffect } from 'react';
import { LiaShoppingBasketSolid } from "react-icons/lia";
import Order from './Order';

const showOrders = (props) => {
  let summa = 0;
  props.orders.forEach(el => summa += Number.parseFloat(el.price));
  return (
    <div>
      {props.orders.map(el => (
        <Order onDelete={props.onDelete} key={el.id} item={el} />
      ))}
      <p className='summa'> Сумма: {new Intl.NumberFormat().format(summa)}Р</p>
    </div>
  );
};

const showNothing = () => {
  return (
    <div className='empty'>
      <h2>Товаров нет</h2>
    </div>
  );
};

const RegistrationForm = ({ onRegister, onLogin, onClose }) => {
  const [isRegister, setIsRegister] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isRegister) {
      onRegister(username, password);
    } else {
      onLogin(username, password);
    }
    onClose();
  };

  return (
    <div className='modal-content'>
      <h2>{isRegister ? 'Регистрация' : 'Вход'}</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Имя пользователя:</label>
          <input type='text' value={username} onChange={(e) => setUsername(e.target.value)} required />
        </div>
        <div>
          <label>Пароль:</label>
          <input type='password' value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        <button type='submit'>{isRegister ? 'Зарегистрироваться' : 'Войти'}</button>
        <button type='button' onClick={() => setIsRegister(!isRegister)}>
          {isRegister ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Зарегистрироваться'}
        </button>
      </form>
    </div>
  );
};

const PersonalCabinet = ({ onLogout, username }) => {
  return (
    <div className='personal-cabinet'>
      <h2>Личный кабинет</h2>
      <p>Добро пожаловать, {username}!</p>
      <button onClick={onLogout}>Выйти</button>
    </div>
  );
};

export default function Header(props) {
  const [cartOpen, setCartOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [username, setUsername] = useState('');

  useEffect(() => {
    if (!isLoggedIn) {
      setShowModal(true);
    }
  }, [isLoggedIn]);

  const handleRegister = (username, password) => {
    // Логика регистрации
    console.log('Register:', username, password);
    setUsername(username);
    setIsLoggedIn(true);
  };

  const handleLogin = (username, password) => {
    // Логика входа
    console.log('Login:', username, password);
    setUsername(username);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername('');
    setCartOpen(false); // Закрыть корзину при выходе
  };

  const handleCabinetClick = () => {
    if (isLoggedIn) {
      setShowModal(false);
    } else {
      setShowModal(true);
    }
  };

  return (
    <header>
      <div>
        <span className='logo'>Home Smart</span>
        <ul className='nav'>
          <li>Про нас</li>
          <li>Контакты</li>
          <li onClick={handleCabinetClick}>{isLoggedIn ? username : 'Кабинет'}</li>
        </ul>
        {isLoggedIn && (
          <LiaShoppingBasketSolid onClick={() => setCartOpen(!cartOpen)} className={`shop-cart-button ${cartOpen && 'active'}`} />
        )}
        {cartOpen && isLoggedIn && (
          <div className='shop-cart'>
            {props.orders.length > 0 ? showOrders(props) : showNothing()}
          </div>
        )}
      </div>
      <div className='presentation'></div>
      {showModal && (
        <div className='modal'>
          <RegistrationForm
            onRegister={handleRegister}
            onLogin={handleLogin}
            onClose={() => setShowModal(false)}
          />
        </div>
      )}
      {isLoggedIn && <PersonalCabinet onLogout={handleLogout} username={username} />}
    </header>
  );
}
