import React from 'react'

export default function Footer(){
  return (
    <footer>    
        Все права защищены &copy;
    </footer>
  )
}